#if defined(HAVE_CONFIG_H)
#include "resip/stack/config.hxx"
#endif
#include "resip/stack/StatisticsHandler.hxx"

using namespace resip;

ExternalStatsHandler::~ExternalStatsHandler()
{}
